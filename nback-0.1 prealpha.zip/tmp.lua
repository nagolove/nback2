﻿--[[
Example of class

   ]]
local inspect = require "inspect"

chart_render = {}

function chart_render:new()

    local self = {}

    self.megadata = "Important string"

    function self:render(func)
        for i = 1, 10 do
            func(self, i)
        end
    end

    return self
end

function draw_chart()
end

function counter()
    local i = 0

    return  function() 
                i = i + 1
                print("count", i)
            end
end

function adaptor(func)
    return  function(a, b)
                func()
            end
end

--cr = chart_render:new()
--cr:render(adaptor(counter()))

t = {
    data1 = "data1",
    data2 = "yes!",
    render1 = chart_render:new(),
    render2 = chart_render:new(),
}

function foo(...) 
    for k,v in pairs({...}) do 
        print(k,v) 
    end 
end

foo("da", "sdfs")

function font_step(fname, ...)
    t[fname]:render(adaptor(counter()))

    print("-- font_step() arguments:")
    for i, v in ipairs({...}) do
        print(i, v)
    end
    print("--")
    --t.fname:render(adaptor(counter()))
end

font_step("render1", font_step, "string data")
font_step("render1", "other", "string data")

function printg()
    for k in pairs(_G) do
        print(k)
    end
end

--print(inspect(_G))

layout = {
    name = "root",
    --w, h
    --x, y
    lcolumn = {
    },
    rcolumn = {
    },
    ccolumn = {
    }
}

function layout.setup()

    layout.place(0, 0, g.w, g.h)
    layout.split(layout, "")

end
